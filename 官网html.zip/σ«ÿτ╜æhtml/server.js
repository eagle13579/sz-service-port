const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');
const compression = require('compression');

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件配置
app.use(compression());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 静态文件服务
app.use(express.static('public'));

// 确保上传目录存在
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// 数据库初始化
const db = new sqlite3.Database('./materials.db', (err) => {
    if (err) {
        console.error('数据库连接失败:', err.message);
    } else {
        console.log('已连接到 SQLite 数据库');
        initializeDatabase();
    }
});

// 初始化数据库表
function initializeDatabase() {
    const createMaterialsTable = `
        CREATE TABLE IF NOT EXISTS materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT UNIQUE NOT NULL,
            category TEXT NOT NULL,
            type TEXT NOT NULL,
            filename TEXT NOT NULL,
            original_name TEXT NOT NULL,
            file_size INTEGER NOT NULL,
            mime_type TEXT NOT NULL,
            description TEXT,
            uploader_info TEXT,
            upload_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )
    `;

    const createCategoriesTable = `
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            display_name TEXT NOT NULL,
            description TEXT,
            created_time DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `;

    db.run(createMaterialsTable);
    db.run(createCategoriesTable);

    // 插入默认分类数据
    const defaultCategories = [
        ['home', '首页', '网站首页相关素材'],
        ['training', '出海培训', '出海培训相关素材'],
        ['solutions', '出海解决方案', '出海解决方案相关素材'],
        ['operations', '增长运营', '增长运营相关素材'],
        ['incubation', '投资孵化', '投资孵化相关素材'],
        ['community', '出海社群', '出海社群相关素材']
    ];

    defaultCategories.forEach(([name, display_name, description]) => {
        db.run(
            'INSERT OR IGNORE INTO categories (name, display_name, description) VALUES (?, ?, ?)',
            [name, display_name, description]
        );
    });
}

// 文件上传配置
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
        const uniqueName = uuidv4() + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB 限制
    },
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('不支持的文件类型'), false);
        }
    }
});

// API 路由

// 获取所有素材
app.get('/api/materials', (req, res) => {
    const query = `
        SELECT m.*, c.display_name as category_display 
        FROM materials m 
        LEFT JOIN categories c ON m.category = c.name 
        WHERE m.status = 'active' 
        ORDER BY m.upload_time DESC
    `;
    
    db.all(query, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// 获取分类统计
app.get('/api/statistics', (req, res) => {
    const query = `
        SELECT c.name, c.display_name, COUNT(m.id) as count
        FROM categories c
        LEFT JOIN materials m ON c.name = m.category AND m.status = 'active'
        GROUP BY c.name, c.display_name
    `;
    
    db.all(query, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// 上传素材
app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: '请选择文件' });
    }

    const { category, type, description, uploader_info } = req.body;
    
    const material = {
        uuid: uuidv4(),
        category: category || 'unknown',
        type: type || 'general',
        filename: req.file.filename,
        original_name: req.file.originalname,
        file_size: req.file.size,
        mime_type: req.file.mimetype,
        description: description || '',
        uploader_info: uploader_info || ''
    };

    const query = `
        INSERT INTO materials (uuid, category, type, filename, original_name, file_size, mime_type, description, uploader_info)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(query, [
        material.uuid,
        material.category,
        material.type,
        material.filename,
        material.original_name,
        material.file_size,
        material.mime_type,
        material.description,
        material.uploader_info
    ], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        res.json({
            success: true,
            message: '文件上传成功',
            material: {
                id: this.lastID,
                ...material
            }
        });
    });
});

// 下载文件
app.get('/api/download/:uuid', (req, res) => {
    const uuid = req.params.uuid;
    
    db.get('SELECT * FROM materials WHERE uuid = ? AND status = "active"', [uuid], (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (!row) {
            res.status(404).json({ error: '文件不存在' });
            return;
        }
        
        const filePath = path.join(uploadsDir, row.filename);
        res.download(filePath, row.original_name);
    });
});

// 删除素材
app.delete('/api/materials/:uuid', (req, res) => {
    const uuid = req.params.uuid;
    
    db.run('UPDATE materials SET status = "deleted" WHERE uuid = ?', [uuid], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (this.changes === 0) {
            res.status(404).json({ error: '素材不存在' });
            return;
        }
        
        res.json({ success: true, message: '素材已删除' });
    });
});

// 导出数据为CSV
app.get('/api/export/csv', (req, res) => {
    const query = `
        SELECT m.original_name, c.display_name as category, m.type, m.file_size, m.upload_time, m.description
        FROM materials m
        LEFT JOIN categories c ON m.category = c.name
        WHERE m.status = 'active'
        ORDER BY m.upload_time DESC
    `;
    
    db.all(query, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        let csvContent = '文件名,分类,类型,文件大小,上传时间,描述\n';
        
        rows.forEach(row => {
            const size = (row.file_size / 1024).toFixed(2) + ' KB';
            const time = new Date(row.upload_time).toLocaleString('zh-CN');
            csvContent += `"${row.original_name}","${row.category}","${row.type}","${size}","${time}","${row.description || ''}"\n`;
        });
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename="material-collection-export.csv"');
        res.send(csvContent);
    });
});

// 默认路由 - 提供前端页面
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 错误处理中间件
app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({ error: '文件大小超过限制（10MB）' });
        }
    }
    
    console.error(err);
    res.status(500).json({ error: '服务器内部错误' });
});

// 启动服务器
app.listen(PORT, () => {
    console.log(`🚀 素材收集工具服务器已启动`);
    console.log(`📍 访问地址: http://localhost:${PORT}`);
    console.log(`📊 管理后台: http://localhost:${PORT}/admin`);
    console.log(`📁 上传目录: ${uploadsDir}`);
});

// 优雅关闭
process.on('SIGINT', () => {
    console.log('\n正在关闭服务器...');
    db.close((err) => {
        if (err) {
            console.error('数据库关闭错误:', err.message);
        } else {
            console.log('数据库连接已关闭');
        }
        process.exit(0);
    });
});