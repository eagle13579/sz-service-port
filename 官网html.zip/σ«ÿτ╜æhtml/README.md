# 数智服务港 - 素材收集工具

## 📋 项目简介

这是一个专门为"数智服务港"网站设计的在线素材收集工具，支持多人协作上传和管理网站建设所需的各类素材。

## ✨ 功能特性

- **📁 多分类素材收集**：支持首页、出海培训、出海解决方案等六大板块
- **👥 多人协作**：支持多用户同时上传素材
- **📊 实时统计**：提供详细的收集进度和数据统计
- **🔒 安全可靠**：文件类型检查、大小限制、数据备份
- **📱 响应式设计**：适配各种设备屏幕
- **📤 数据导出**：支持CSV格式数据导出

## 🚀 快速部署

### 方式一：使用 Docker（推荐）

1. **安装 Docker 和 Docker Compose**

2. **启动服务**
   ```bash
   docker-compose up -d
   ```

3. **访问应用**
   - 前台界面：http://localhost:3000
   - 管理后台：http://localhost:3000/admin

### 方式二：传统部署

1. **安装 Node.js (版本 14+)**

2. **安装依赖**
   ```bash
   npm install
   ```

3. **启动服务**
   ```bash
   npm start
   ```

4. **生产环境启动**
   ```bash
   NODE_ENV=production npm start
   ```

## 📁 项目结构

```
├── public/                 # 前端静态文件
│   ├── index.html         # 用户界面
│   └── admin.html         # 管理后台
├── uploads/               # 文件上传目录
├── materials.db           # SQLite数据库
├── server.js              # 服务器主文件
├── package.json           # 项目配置
├── Dockerfile             # Docker镜像配置
├── docker-compose.yml     # Docker编排配置
└── README.md              # 项目说明
```

## 🔧 配置说明

### 环境变量

```bash
PORT=3000                  # 服务端口
NODE_ENV=production       # 运行环境
```

### 文件上传配置

- **支持格式**：JPEG, PNG, GIF, PDF, DOC, DOCX
- **大小限制**：单个文件最大 10MB
- **存储位置**：`./uploads` 目录

## 📊 API接口

### 获取素材列表
```
GET /api/materials
```

### 上传素材
```
POST /api/upload
Content-Type: multipart/form-data
```

### 下载文件
```
GET /api/download/:uuid
```

### 数据导出
```
GET /api/export/csv
```

## 🛠️ 开发指南

### 本地开发

```bash
# 安装依赖
npm install

# 开发模式启动
npm run dev

# 生产模式启动
npm start
```

### 数据库操作

项目使用 SQLite 数据库，数据库文件为 `materials.db`。

主要数据表：
- `materials` - 素材信息表
- `categories` - 分类信息表

## 🌐 部署到云平台

### Vercel 部署

1. Fork 本项目
2. 在 Vercel 中导入项目
3. 配置环境变量
4. 部署完成

### 其他平台

- **Railway**: 支持 Docker 部署
- **Heroku**: 需要配置 buildpack
- **阿里云/腾讯云**: 使用 Docker 镜像部署

## 🔒 安全注意事项

1. **文件类型验证**：服务器会验证上传文件的MIME类型
2. **大小限制**：防止大文件攻击
3. **SQL注入防护**：使用参数化查询
4. **XSS防护**：前端输入转义处理
5. **定期备份**：建议定期备份数据库和上传文件

## 📞 技术支持

如遇问题，请检查：

1. 端口 3000 是否被占用
2. Node.js 版本是否符合要求
3. 上传目录是否有写入权限
4. 数据库文件是否可正常读写

## 📄 许可证

MIT License

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request 来改进这个项目。